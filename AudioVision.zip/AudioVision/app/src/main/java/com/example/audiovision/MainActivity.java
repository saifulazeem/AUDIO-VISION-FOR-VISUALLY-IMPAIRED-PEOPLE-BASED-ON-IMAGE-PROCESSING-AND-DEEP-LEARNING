package com.example.audiovision;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    Camera camera;
    FrameLayout frameLayout;
    ShowCamera showcamera;
    Button btn_cature, btn_gallery;
    ImageView myimageview;
    TextToSpeech tts, tts1;
    Bitmap bitmap;
    Uri imageuri;
    TextView tv1;




    String cap_img_btn_description="Capture Image From Camera.";
    String imp_img_btn_description="Import Image From Gallery";

    private static final int CAMERA_REQUEST=1777;
    private static final int IMAGE_PICK_CODE=1000;
    private static  final int PERMISSION_CODE=1001;



    int i=0;
    int j=0;
    int img_ok=0;
   // byte[] bytearry;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        frameLayout =(FrameLayout) findViewById(R.id.frame);
        btn_cature=(Button)findViewById(R.id.btn_capture_image);
        btn_gallery=(Button)findViewById(R.id.btn_gallery_image);
        myimageview=(ImageView)findViewById(R.id.img_view);
        tv1=(TextView)findViewById(R.id.tv1);



        tts1 = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    tts1.setLanguage(Locale.UK);
                }
            }
        });

        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    tts.setLanguage(Locale.UK);
                }
            }
        });




        //camera = Camera.open();

        camera = getCameraInstance();
        showcamera=new ShowCamera(this,camera);
        frameLayout.addView(showcamera);





        btn_cature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                j++;
                Handler handler1=new Handler();
                handler1.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        if (j==1)
                        {

                            //Changes from 28dec
                            String toSpeak = cap_img_btn_description;
                            Toast.makeText(getApplicationContext(), toSpeak,Toast.LENGTH_SHORT).show();
                            tts1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
                            //Change till here..
                            //Toast.makeText(MainActivity.this,"Single Tap", Toast.LENGTH_SHORT).show();
                        }

                        else if (j==2)
                        {
                            // change on 29/04/2020 //Intent capture_image= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                            //change on 29/04/2020 //startActivityForResult(capture_image,CAMERA_REQUEST);




                            if(camera!=null)
                            {
                                camera.takePicture(null,null,mPicturecallback);
                            }
                        }

                        j=0;


                    }
                },500);

            }
        });




        //Gallery button
        btn_gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                i++;

                Handler handler=new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        if (i==1)
                        {


                            String toSpeak = imp_img_btn_description;
                            Toast.makeText(getApplicationContext(), toSpeak,Toast.LENGTH_SHORT).show();
                            tts.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);

                        }

                        else if(i==2)
                        {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            {
                                if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED)
                                {
                                    //Request permission if not granted
                                    String[] permission = {Manifest.permission.READ_EXTERNAL_STORAGE};
                                    //Show pop up
                                    requestPermissions(permission, PERMISSION_CODE);
                                }
                                else {
                                    pickImageFromGallery();



                                }
                            }
                            else{
                                //version lower
                                pickImageFromGallery();


                            }


                        }
                        i=0;


                    }
                },500);


            }

        });






    }

    Camera.PictureCallback mPicturecallback=new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            Toast toast= Toast.makeText(getApplicationContext(),"Picture Taken", Toast.LENGTH_SHORT);
            toast.show();
            byte [] bytes_image=data;
            bitmap= BitmapFactory.decodeByteArray(bytes_image,0,bytes_image.length);
            myimageview.setImageBitmap(bitmap);
            myimageview.setVisibility(View.VISIBLE);
            generater_server_request();

            MainActivity.this.camera.startPreview();

        }
    };



    private void pickImageFromGallery()
        {
            Intent gallery_image= new Intent(Intent.ACTION_PICK);
            gallery_image.setType("image/*");
            startActivityForResult(gallery_image,IMAGE_PICK_CODE);


        //Intent gally_image= new Intent(Intent.ACTION_PICK);
        //gally_image.setType("image/*");
        //gally_image.setAction(Intent.ACTION_GET_CONTENT);
        //startActivityForResult(gally_image, IMAGE_PICK_CODE);


        }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);



        switch (requestCode){
            case PERMISSION_CODE:{
                if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    pickImageFromGallery();
                }
                else {
                    Toast.makeText(this,"Permission Denied...", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==IMAGE_PICK_CODE && resultCode== RESULT_OK && data!=null)
        {
            imageuri=data.getData();
            try {
                bitmap=MediaStore.Images.Media.getBitmap(getContentResolver(), imageuri);
                myimageview.setImageBitmap(bitmap);
                myimageview.setVisibility(View.VISIBLE);
                generater_server_request();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }


    }






    public static Camera getCameraInstance()
    {
        Camera c = null;
        try {
            c = Camera.open(); // attempt to get a Camera instance
        }
        catch (Exception e){
            // Camera is not available (in use or does not exist)
        }
        return c; // returns null if camera is unavailable
    }



   // public void onPause(){
   // if(tts !=null && tts1 !=null){
    //    tts.stop();
     //  tts.shutdown();
      //  tts1.stop();
      // tts1.shutdown();
    //}
   // super.onPause();
    //}



    private void generater_server_request()
    {

        //String ipv4Addresss = ipv4Address.getText().toString();
        String ipv4Addresss="192.168.10.10";


        String postUrl= "http://"+ipv4Addresss+":5000/";



        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] bytearry = byteArrayOutputStream.toByteArray();


        //String image_str =ImageToString(bitmap);

        RequestBody postBodyImage = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("image", "androidFlask.jpg", RequestBody.create(MediaType.parse("image/*jpg"),bytearry ))
                .build();

        tv1.setText("Please wait ...");
        //Toast.makeText(getApplicationContext(),"Please wait",Toast.LENGTH_SHORT).show();

        String msg="Please wait Image is processing";
        tts.speak(msg, TextToSpeech.QUEUE_FLUSH, null);


        postRequest(postUrl, postBodyImage);



    }

    void postRequest(final String postUrl, RequestBody postBody) {
        final OkHttpClient client;


        client = new OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .writeTimeout(5, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                //.callTimeout(30, TimeUnit.SECONDS)
                .build();

        //chnage april from

        //client =new OkHttpClient.Builder()
        //   .connectTimeout(5, TimeUnit.SECONDS)
        //   .writeTimeout(5, TimeUnit.SECONDS)
        //    .readTimeout(5, TimeUnit.SECONDS)
        //   .build();

        //chnage april to



        Request request = new Request.Builder()
                .url(postUrl)
                .post(postBody)
                .build();



        client.newCall(request).enqueue(new Callback() {


            @Override
            public void onFailure(Call call, IOException e) {
                // Cancel the post on failure.
                call.cancel();



                // In order to access the TextView inside the UI thread, the code is executed inside runOnUiThread()
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {


                        String fail_msg="Failed to Connect to Server";

                        tv1.setText(fail_msg);
                        Toast.makeText(getApplicationContext(),"Serve Conncetion Fail",Toast.LENGTH_SHORT).show();
                        tts.speak(fail_msg, TextToSpeech.QUEUE_FLUSH, null);




                    }
                });
            }



            //line 95 throw IOException
            @Override
            public void onResponse(Call call, final Response response) throws IOException  {
                // In order to access the TextView inside the UI thread, the code is executed inside runOnUiThread()
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        try {
                            tv1.setText(response.body().string());
                            Toast.makeText(getApplicationContext(),tv1.getText(),Toast.LENGTH_LONG).show();
                            tts.speak(tv1.getText().toString(), TextToSpeech.QUEUE_FLUSH, null);
                            myimageview.setVisibility(View.GONE);


                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });



    }






}
