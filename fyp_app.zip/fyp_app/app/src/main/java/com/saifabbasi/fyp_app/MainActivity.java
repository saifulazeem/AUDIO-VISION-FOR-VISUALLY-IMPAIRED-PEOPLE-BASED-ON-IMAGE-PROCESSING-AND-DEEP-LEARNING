package com.saifabbasi.fyp_app;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {


    Button btn_camera_img, btn_gallery_img;
    ImageView display_img;

    TextToSpeech tts;

    String cap_img_btn_description="Capture Image From Camera.";
    String imp_img_btn_description="Import Image From Gallery";

    private static final int CAMERA_REQUEST=1777;
    private static final int IMAGE_PICK_CODE=1000;
    private static  final int PERMISSION_CODE=1001;

    int i=0;
    int j=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_camera_img=(Button)findViewById(R.id.capture_img);
        btn_gallery_img=(Button)findViewById(R.id.import_img);

        display_img=(ImageView)findViewById(R.id.display_img);


    ///Changes from today 28 dec
        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    tts.setLanguage(Locale.UK);
                }
            }
        });

    // Change till here 28dec


        btn_gallery_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                i++;

                Handler handler=new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        if (i==1)
                        {

                           //Changes 28 dec
                            String toSpeak = imp_img_btn_description;
                            Toast.makeText(getApplicationContext(), toSpeak,Toast.LENGTH_SHORT).show();
                            tts.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);

                            //Toast.makeText(MainActivity.this,"Single Tap", Toast.LENGTH_SHORT).show();
                            //till here 28 dec
                        }

                        else if(i==2)
                        {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                            {
                                if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED)
                                {
                                    //Request permission if not granted
                                    String[] permission = {Manifest.permission.READ_EXTERNAL_STORAGE};
                                    //Show pop up
                                    requestPermissions(permission, PERMISSION_CODE);
                                }
                                else {
                                    pickImageFromGallery();

                                }
                            }
                            else{
                                pickImageFromGallery();
                            }

                        }
                        i=0;


                    }
                },500);



                //if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                //{
                  //  if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED)
                    //{
                            //Request permission if not granted
                      //      String[] permission = {Manifest.permission.READ_EXTERNAL_STORAGE};
                            //Show pop up
                        //    requestPermissions(permission, PERMISSION_CODE);
                    //}
                    //else {
                      //  pickImageFromGallery();

                   // }
                //}
               // else{
                 //   pickImageFromGallery();
                //}





            }
        });


        btn_camera_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                j++;
                 Handler handler1=new Handler();
                 handler1.postDelayed(new Runnable() {
                     @Override
                     public void run() {

                         if (j==1)
                         {
                             //Changes from 28dec
                             String toSpeak = cap_img_btn_description;
                             Toast.makeText(getApplicationContext(), toSpeak,Toast.LENGTH_SHORT).show();
                             tts.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
                             //Change till here..
                             //Toast.makeText(MainActivity.this,"Single Tap", Toast.LENGTH_SHORT).show();
                         }

                         else if (j==2)
                         {
                             Intent capture_image= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                             startActivityForResult(capture_image,CAMERA_REQUEST);
                         }

                         j=0;


                     }
                 },500);


                //Intent capture_image= new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

               // startActivityForResult(capture_image,CAMERA_REQUEST);



            }
        });


    }

    private void pickImageFromGallery() {

        Intent gally_image= new Intent(Intent.ACTION_PICK);
        gally_image.setType("image/*");
        startActivityForResult(gally_image, IMAGE_PICK_CODE);



    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode){
            case PERMISSION_CODE:{
                if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    pickImageFromGallery();
                }
                else {
                    Toast.makeText(this,"Permission Denied...", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK)


        {
            Bitmap capt_img=(Bitmap)data.getExtras().get("data");
            display_img.setImageBitmap(capt_img);
        }


        if (resultCode == RESULT_OK && requestCode == IMAGE_PICK_CODE )
        {
            display_img.setImageURI(data.getData());
        }
    }

   //Changes from 28 dec
   // public void onPause(){
       // if(tts !=null){
        //    tts.stop();
        //    tts.shutdown();
       // }
       // super.onPause();
   // }
    // Change till here..
}
