package com.example.my_app;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Camera;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Camera camera;
    FrameLayout frameLayout;
    showcamera showcameraa;
    Button btn_capture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        frameLayout =(FrameLayout) findViewById(R.id.frame);
        btn_capture=(Button) findViewById(R.id.capt_img);

        camera = Camera.open();
        showcameraa=new showcamera(this,camera);
        frameLayout.addView(showcameraa);

        btn_capture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(camera!=null)
                {
                    camera.takePicture(null,null,mPicturecallback);
                }
            }
        });



    }
    Camera.PictureCallback mPicturecallback=new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
           Toast toast= Toast.makeText(getApplicationContext(),"Picture Taken", Toast.LENGTH_SHORT);
           toast.show();
           MainActivity.this.camera.startPreview();

        }
    };

}
